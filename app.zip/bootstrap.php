<?php 

    session_start();

    require "vendor/autoload.php";
?>